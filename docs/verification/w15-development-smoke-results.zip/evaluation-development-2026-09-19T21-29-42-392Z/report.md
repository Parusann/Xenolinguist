# Baseline evaluation

| Split | Method | Observations | Languages / runs | Semantic | Coverage | Lexical | Withheld forms | Model calls | Median batch ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| development | exact-lookup | 8 | 1 / 1 | 0.0% | 0.0% | 77.8% | 0.0% | 0 | 1.1 |
| development | symbolic | 8 | 1 / 1 | 0.0% | 0.0% | 77.8% | 0.0% | 0 | 0.7 |
| development | llm-only | 8 | 1 / 2 | 0.0% | 0.0% | 44.4% | 0.0% | 2 | 5053.4 |
| development | hybrid | 8 | 1 / 2 | 0.0% | 0.0% | 77.8% | 0.0% | 2 | 4776.6 |
| development | exact-lookup | 29 | 1 / 1 | 0.0% | 0.0% | 100.0% | 0.0% | 0 | 0.8 |
| development | symbolic | 29 | 1 / 1 | 100.0% | 100.0% | 100.0% | 100.0% | 0 | 1.2 |
| development | llm-only | 29 | 1 / 2 | 0.0% | 80.0% | 33.3% | 0.0% | 2 | 6060.0 |
| development | hybrid | 29 | 1 / 2 | 100.0% | 100.0% | 100.0% | 100.0% | 0 | 0.7 |

## Paired differences

- development, 8 observations, symbolic minus exact-lookup: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 8 observations, llm-only minus exact-lookup: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 8 observations, hybrid minus exact-lookup: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 8 observations, llm-only minus symbolic: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 8 observations, hybrid minus symbolic: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 8 observations, hybrid minus llm-only: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 29 observations, symbolic minus exact-lookup: 100.0% [100.0%, 100.0%], 1 paired languages.
- development, 29 observations, llm-only minus exact-lookup: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 29 observations, hybrid minus exact-lookup: 100.0% [100.0%, 100.0%], 1 paired languages.
- development, 29 observations, llm-only minus symbolic: -100.0% [-100.0%, -100.0%], 1 paired languages.
- development, 29 observations, hybrid minus symbolic: 0.0% [0.0%, 0.0%], 1 paired languages.
- development, 29 observations, hybrid minus llm-only: 100.0% [100.0%, 100.0%], 1 paired languages.

## Interpretation limits

- Synthetic bounded grammar with supplied hypothesis class; not unrestricted language acquisition.
- Accuracy uses every item, including abstentions, invalid responses, transport errors and timeouts.
- Latency is wall time for an entire language batch (training plus all probes), not a per-item measurement.
- Bootstrap intervals condition on the frozen languages and configuration; they do not model corpus design uncertainty.
- Withheld forms contain at least one entity count absent from the full training corpus; all challenge compositions are withheld.
- Calibration unavailable: no baseline declares probability semantics.
- Read manifest.json for configuration, source identity, completion status and raw hashes.
