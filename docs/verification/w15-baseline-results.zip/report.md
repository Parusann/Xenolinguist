# Baseline evaluation

| Split | Method | Observations | Languages / runs | Semantic | Coverage | Lexical | Withheld forms | Model calls | Median batch ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| evaluation | exact-lookup | 8 | 30 / 30 | 0.0% | 0.0% | 81.9% | 0.0% | 0 | 0.4 |
| evaluation | symbolic | 8 | 30 / 30 | 0.0% | 0.0% | 81.9% | 0.0% | 0 | 0.3 |
| evaluation | llm-only | 8 | 30 / 60 | 0.0% | 30.0% | 24.8% | 0.0% | 60 | 4625.1 |
| evaluation | hybrid | 8 | 30 / 60 | 0.0% | 13.0% | 81.9% | 0.0% | 60 | 3974.2 |
| evaluation | exact-lookup | 16 | 30 / 30 | 0.0% | 0.0% | 91.1% | 0.0% | 0 | 0.6 |
| evaluation | symbolic | 16 | 30 / 30 | 2.7% | 2.7% | 91.1% | 3.6% | 0 | 0.3 |
| evaluation | llm-only | 16 | 30 / 60 | 0.0% | 37.3% | 38.9% | 0.0% | 60 | 4635.5 |
| evaluation | hybrid | 16 | 30 / 60 | 2.7% | 7.7% | 91.1% | 3.6% | 60 | 1550.5 |
| evaluation | exact-lookup | 29 | 30 / 30 | 0.0% | 0.0% | 100.0% | 0.0% | 0 | 0.6 |
| evaluation | symbolic | 29 | 30 / 30 | 100.0% | 100.0% | 100.0% | 100.0% | 0 | 0.6 |
| evaluation | llm-only | 29 | 30 / 60 | 0.0% | 15.0% | 38.3% | 0.0% | 60 | 5474.2 |
| evaluation | hybrid | 29 | 30 / 60 | 100.0% | 100.0% | 100.0% | 100.0% | 0 | 0.6 |

## Paired differences

- evaluation, 8 observations, symbolic minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 8 observations, llm-only minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 8 observations, hybrid minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 8 observations, llm-only minus symbolic: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 8 observations, hybrid minus symbolic: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 8 observations, hybrid minus llm-only: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 16 observations, symbolic minus exact-lookup: 2.7% [0.0%, 7.3%], 30 paired languages.
- evaluation, 16 observations, llm-only minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 16 observations, hybrid minus exact-lookup: 2.7% [0.0%, 7.3%], 30 paired languages.
- evaluation, 16 observations, llm-only minus symbolic: -2.7% [-7.3%, 0.0%], 30 paired languages.
- evaluation, 16 observations, hybrid minus symbolic: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 16 observations, hybrid minus llm-only: 2.7% [0.0%, 7.3%], 30 paired languages.
- evaluation, 29 observations, symbolic minus exact-lookup: 100.0% [100.0%, 100.0%], 30 paired languages.
- evaluation, 29 observations, llm-only minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 29 observations, hybrid minus exact-lookup: 100.0% [100.0%, 100.0%], 30 paired languages.
- evaluation, 29 observations, llm-only minus symbolic: -100.0% [-100.0%, -100.0%], 30 paired languages.
- evaluation, 29 observations, hybrid minus symbolic: 0.0% [0.0%, 0.0%], 30 paired languages.
- evaluation, 29 observations, hybrid minus llm-only: 100.0% [100.0%, 100.0%], 30 paired languages.

## Interpretation limits

- Synthetic bounded grammar with supplied hypothesis class; not unrestricted language acquisition.
- Accuracy uses every item, including abstentions, invalid responses, transport errors and timeouts.
- Latency is wall time for an entire language batch (training plus all probes), not a per-item measurement.
- Bootstrap intervals condition on the frozen languages and configuration; they do not model corpus design uncertainty.
- Withheld forms contain at least one entity count absent from the full training corpus; all challenge compositions are withheld.
- Calibration unavailable: no baseline declares probability semantics.
- Read manifest.json for configuration, source identity, completion status and raw hashes.
