# Baseline evaluation

| Split | Method | Observations | Languages / runs | Semantic | Coverage | Lexical | Withheld forms | Model calls | Median batch ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| structural | exact-lookup | 8 | 30 / 30 | 0.0% | 0.0% | 82.6% | 0.0% | 0 | 0.3 |
| structural | symbolic | 8 | 30 / 30 | 0.0% | 0.0% | 82.6% | 0.0% | 0 | 0.3 |
| structural | exact-lookup | 16 | 30 / 30 | 0.0% | 0.0% | 89.6% | 0.0% | 0 | 0.3 |
| structural | symbolic | 16 | 30 / 30 | 0.0% | 0.0% | 89.6% | 0.0% | 0 | 0.3 |
| structural | exact-lookup | 29 | 30 / 30 | 0.0% | 0.0% | 100.0% | 0.0% | 0 | 0.4 |
| structural | symbolic | 29 | 30 / 30 | 100.0% | 100.0% | 100.0% | 100.0% | 0 | 0.4 |

## Paired differences

- structural, 8 observations, symbolic minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- structural, 16 observations, symbolic minus exact-lookup: 0.0% [0.0%, 0.0%], 30 paired languages.
- structural, 29 observations, symbolic minus exact-lookup: 100.0% [100.0%, 100.0%], 30 paired languages.

## Interpretation limits

- Synthetic bounded grammar with supplied hypothesis class; not unrestricted language acquisition.
- Accuracy uses every item, including abstentions, invalid responses, transport errors and timeouts.
- Latency is wall time for an entire language batch (training plus all probes), not a per-item measurement.
- Bootstrap intervals condition on the frozen languages and configuration; they do not model corpus design uncertainty.
- Withheld forms contain at least one entity count absent from the full training corpus; all challenge compositions are withheld.
- Calibration unavailable: no baseline declares probability semantics.
- Read manifest.json for configuration, source identity, completion status and raw hashes.
